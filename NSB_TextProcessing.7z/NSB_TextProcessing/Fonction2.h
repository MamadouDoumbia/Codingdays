// ----------------------------------------------------------------------------
//
// Description:
//		This function allow to read a file, search for, replace text within a string and save
//		into a new file after le processing.
//
// Parameters:
//    const char fileReadName[1000], const char *from, const char *to, const char fileOutputName[1000]
//    fileReadName (in) - tab contains the source file name (Ex: char filename1[1000] = "file.txt";)
//	  fileOutputName (in) - tab contains the output file name 
//    separator (in) - pointer to delete text
//    maxTri (in) - pointer to maximum of tri
//
// Returns:
//    Returns a pointer to dynamically-allocated memory containing string
//    with occurences of the text pointed to by 'from' replaced by with
//    the text pointed to by 'to'.
//
//
// ----------------------------------------------------------------------------

char * strSelectLines(const char fileReadName[1000], const char separators[100], const int maxTri, const char fileOutputName[1000])
{
	long fileRead	= fopen ( fileReadName, "r+" );
	long fileOutput	= fopen ( fileOutputName, "w+" );
	char line [ 4000 ];
	char lineToCopy [ 4000 ];
	char tempLine [ 4000 ]; // cette valeur permet de stocker la ligne fraichement trait�e
	char *token;
	char tokenTemp1[ 4000 ], tokenTemp2[ 4000 ];
	int result, counter;
//	int maxTri;
	
	if (( fileRead != NULL ) && ( fileOutput != NULL ))
   {
		counter =1;
		strcpy(tokenTemp2, "");
      while ( fgets ( line, 1024, fileRead ) != NULL ) /* read a line */
      {
      	lr_output_message( "The first line is \"%s\"", line);
      	strcpy(lineToCopy, line);
      	token = (char *)strtok(line, separators);// join en parametre
      	strcpy(tokenTemp1, token);
		lr_output_message ("%s", token );
		result = strcmp( tokenTemp1, tokenTemp2);
		lr_output_message( "resultat \"%d\"", result);
//		if ((result==0) && (counter<10)){
//			strcpy(tempLine, lineToCopy);
//			counter +=1;
//			lr_output_message( "inferieur � 10 is apr�s token \"%s\"", lineToCopy);
//			strcpy(tokenTemp2, token);
//		} else if ((result!=0)){
//			strcpy(tempLine, lineToCopy);
//			strcpy(tokenTemp2, token);
//			lr_output_message( "The first line is apr�s token \"%s\"", lineToCopy);
//		}
		
		if ((result!=0)){		
			strcpy(tempLine, lineToCopy);
			strcpy(tokenTemp2, token);
			lr_output_message( "superieur � 10 is apr�s token \"%s\"", lineToCopy);
			fprintf(fileOutput, tempLine);
			counter =1;
		} else if ((result==0) && (counter<maxTri)){
			strcpy(tempLine, lineToCopy);
			counter +=1;
			lr_output_message( "inferieur � 10 is apr�s token \"%s\"", lineToCopy);
			strcpy(tokenTemp2, token);
			fprintf(fileOutput, tempLine);
		}
		//creeer un compteur ici et faire un cpy si (while) token-1 # token+1 ou compteur <10 
//			strcpy(tempLine, strReplace(line, from, to));
//			fprintf(fileOutput, tempLine);
//		lr_output_message( "The convert line is \"%s\"", tempLine);
//			fprintf(fileOutput, "\n");
      }
      fclose ( fileRead );
      fclose ( fileOutput );
   }
   else 
   {
		lr_error_message("Cannot open or not extist : %s (processing file)", fileReadName);

		return 0;
   }
//   lr_output_message( "File processing is successfully ended");
	return 0;
}