Action()
{
	long file_stream;
	char *line;
   char filename1[1000] = "file4.txt";
	char filename2[1000] = "file2.txt";
	char filename5[1000] = "file5.txt";
	char separator[1000] = "";
	strSpliter(filename1, separator, "", filename2);
	
	strSelectLines(filename1, "	", 2, filename5);
//	strReplaceFile(filename1, "*", "", filename3);
	return 0;
}
